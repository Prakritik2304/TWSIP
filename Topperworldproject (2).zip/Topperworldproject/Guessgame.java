import java.util.Scanner;
import java.util.Random;

public class Guessgame {
    public static void main(String[] args) {
        Random rd = new Random();
        int num = rd.nextInt(100) + 1;
        Scanner sc = new Scanner(System.in);
        int guess;
        System.out.println("Welcome to the number guessing game");
        System.out.println("Guess a number between 1 and 100:-");
        System.out.println("You have 5 trials to make sure of the game");
        for (int i = 0; i < 5; i++) {
            guess = sc.nextInt();
            if (guess == num) {
                System.out.println("Congratulations you've guessed the number");
                break;
            } else if (guess < num) {
                System.out.println("The number is too low");
            } else {
                System.out.println("The number is too high");
            }
        }
        System.out.println("You are out of trials");
        System.out.println("the number is" + num);
    }
}